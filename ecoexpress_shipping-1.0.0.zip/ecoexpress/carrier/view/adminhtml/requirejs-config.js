var config = {
    map: {
        '*': {
            'jquerynew'    : 'Ecoexpress_Carrier/js/jquerynew.min',
            'bootstrap'    : 'Ecoexpress_Carrier/js/bootstrap.bundle',
        }
    }
};
